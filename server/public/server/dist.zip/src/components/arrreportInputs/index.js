import {Handle, DataHandle} from 'nclient-microfront';

class ArrreportInputs extends DataHandle{
  constructor() {
    super('arrreportInputsComp')
    /* data start */
    /* data end */
  }
  init () {
    console.log('ArrreportInputs init')
  }
}

let arrreportInputs = new ArrreportInputs()

let handle = new Handle({
  name: 'arrreportInputsComp',
  created () {
    arrreportInputs.init()
    console.log('arrreportInputs created')
  },
  mounted () {
    console.log('arrreportInputs mounted')
  },
})

export default handle

export {
  arrreportInputs
}